package com.shop.common;

public class PaymentVO {

}
